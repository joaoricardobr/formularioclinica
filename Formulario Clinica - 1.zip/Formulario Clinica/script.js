// Função para validar e enviar os dados do formulário
function validarFormulario(event) {
    event.preventDefault();

    let form = document.getElementById("patientForm");
    let formData = new FormData(form);

    let dados = [];
    formData.forEach((value, key) => {
        if (value) {
            dados.push(`*${key.replace(/([A-Z])/g, ' $1').trim()}:* ${value}`);
            localStorage.setItem(key, value); // Salva os dados no localStorage
        }
    });

    let mensagem = `Olá, estou entrando em contato pelo site e preciso de ajuda com os procedimentos.%0A%0A${dados.join('%0A')}`;

    let telefone = formData.get("Telefone").replace(/\D/g, '');
    if (telefone.length === 11) {
        let linkWhatsApp = `https://api.whatsapp.com/send?phone=55${telefone}&text=${mensagem}`;
        window.open(linkWhatsApp, "_blank");  // Para abrir o WhatsApp tanto em web quanto mobile
    } else {
        alert("Número de telefone inválido. Por favor, insira um número válido.");
        return;
    }

    form.submit();
}

// Função para preencher os campos do formulário com dados salvos
function preencherFormulario() {
    let form = document.getElementById("patientForm");
    let formData = new FormData(form);

    formData.forEach((value, key) => {
        if (localStorage.getItem(key)) {
            form.querySelector(`[name="${key}"]`).value = localStorage.getItem(key);
        }
    });

    let planoSelecionado = formData.get("Plano");
    localStorage.setItem("Plano", planoSelecionado);  // Salva o plano selecionado

    let linkPagamento;
    if (planoSelecionado === "Nenhum plano por enquanto") {
        linkPagamento = "https://linkdopagamento.com/sem-plano";
    } else if (planoSelecionado === "Plano Básico") {
        linkPagamento = "https://linkdopagamento.com/plano-basico";
    } else if (planoSelecionado === "Plano Intermediário") {
        linkPagamento = "https://linkdopagamento.com/plano-intermediario";
    } else if (planoSelecionado === "Plano Avançado") {
        linkPagamento = "https://linkdopagamento.com/plano-avancado";
    }
}

// Chama a função ao carregar a página para preencher os dados salvos
window.onload = preencherFormulario;

